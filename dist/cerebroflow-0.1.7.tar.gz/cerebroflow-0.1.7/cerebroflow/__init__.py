"""
Cerebroflow.

A python library to analyze csf kymographs.
https://pypi.org/project/cerebroflow/
"""

__version__ = "0.1.7"
__author__ = 'Quillan Favey'
__credits__ = 'Bachmann lab'